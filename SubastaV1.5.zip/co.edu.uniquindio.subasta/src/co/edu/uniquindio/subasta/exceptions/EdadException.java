package co.edu.uniquindio.subasta.exceptions;

public class EdadException extends Exception{

	public EdadException(String mensaje){
		super(mensaje);
	}

	public EdadException() {
	}
}
