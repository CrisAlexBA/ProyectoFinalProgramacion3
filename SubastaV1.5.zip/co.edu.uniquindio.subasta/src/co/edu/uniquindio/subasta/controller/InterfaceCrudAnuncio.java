package co.edu.uniquindio.subasta.controller;

public interface InterfaceCrudAnuncio {

	void addAnuncio();
	void deleteAnuncio();
}