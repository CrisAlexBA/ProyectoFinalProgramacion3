package co.edu.uniquindio.subasta.controller;

//import com.gluonhq.charm.glisten.control.BottomNavigationButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;

public class CrudAnuncioController implements InterfaceCrudAnuncio{

//    @FXML
//    private BottomNavigationButton atras;

    @FXML
    private ImageView campoImagen;

    @FXML
    private Button crearAnuncio;

    @FXML
    private TextArea descripsion;

    @FXML
    private DatePicker fechaFinal;

    @FXML
    private DatePicker fechaInicial;

//    @FXML
//    private BottomNavigationButton listaArticulos;

    @FXML
    private TextField nombreArticulo;

    @FXML
    private TextField precioArticulo;

    @FXML
    private ComboBox<?> tipoProducto;

    @FXML
    void CrearAnuncio(ActionEvent event) {

    }

    @FXML
    void ValidarText(KeyEvent event) {

    }

    @FXML
    void mostrarLista(ActionEvent event) {

    }

    @FXML
    void retrocederMenuPrincipal(ActionEvent event) {

    }

	@Override
	public void addAnuncio() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAnuncio() {
		// TODO Auto-generated method stub
		
	}

//	@Override
//	public void addAnuncio() {
//		// TODO Auto-generated method stub
//		
//	}
//
//	@Override
//	public void deleteAnuncio() {
//		// TODO Auto-generated method stub
//		
//	}

}