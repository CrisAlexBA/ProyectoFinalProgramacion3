package co.edu.uniquindio.subasta.exceptions;

public class TipoArticuloException extends Exception{
	
	public TipoArticuloException(String mensaje){
		super(mensaje);
	}
}
