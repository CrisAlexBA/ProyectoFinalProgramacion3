package co.edu.uniquindio.subasta.exceptions;

public class ArticuloException extends Exception{

	public ArticuloException(String mensaje){
		super(mensaje);
	}
}
