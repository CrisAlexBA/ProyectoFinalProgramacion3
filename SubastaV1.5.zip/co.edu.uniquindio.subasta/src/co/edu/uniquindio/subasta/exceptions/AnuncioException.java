package co.edu.uniquindio.subasta.exceptions;

public class AnuncioException extends Exception{
	
	public AnuncioException(String mensaje){
		super(mensaje);
	}
}
