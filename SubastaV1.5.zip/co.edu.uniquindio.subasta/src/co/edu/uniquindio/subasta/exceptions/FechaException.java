package co.edu.uniquindio.subasta.exceptions;

public class FechaException extends Exception{

	public FechaException(String mensaje){
		super(mensaje);
	}
}
