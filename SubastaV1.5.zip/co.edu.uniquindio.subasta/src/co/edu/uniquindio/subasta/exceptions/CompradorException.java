package co.edu.uniquindio.subasta.exceptions;

public class CompradorException extends Exception{

	public CompradorException(String mensaje){
		super(mensaje);
	}
}
