package co.edu.uniquindio.subasta.exceptions;

public class CantidadPujaException extends Exception{
	
	public CantidadPujaException(String mensaje){
		super(mensaje);
	}
}
