package co.edu.uniquindio.subasta.exceptions;

public class AnuncianteException extends Exception{
	
	public AnuncianteException(String mensaje){
		super(mensaje);
	}
}
