package co.edu.uniquindio.subasta.controller;

//import com.gluonhq.charm.glisten.control.BottomNavigationButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

public class CrudArticuloController {

    //@FXML
    //private BottomNavigationButton atras;

    @FXML
    private Button creaqrArticulo;

    @FXML
    private TextField idArticulo;

    @FXML
    private TextField nombreArticulo;

    @FXML
    private ComboBox<?> tipoProducto;

    @FXML
    void CrearArticulo(ActionEvent event) {

    }

    @FXML
    void ValidarText(KeyEvent event) {

    }

    @FXML
    void retrocederMenuPrincipal(ActionEvent event) {

    }

}
